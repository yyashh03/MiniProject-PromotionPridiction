import joblib
import numpy as np
from django.shortcuts import render

# Load model files
model = joblib.load('../ml_model/model.pkl')
scaler = joblib.load('../ml_model/scaler.pkl')
encoders = joblib.load('../ml_model/encoders.pkl')


def home(request):
    if request.method == 'POST':
        try:
            data = {}

            # Categorical
            data['department'] = request.POST.get('department')
            data['region'] = request.POST.get('region')
            data['education'] = request.POST.get('education')
            data['gender'] = request.POST.get('gender')
            data['recruitment_channel'] = request.POST.get('recruitment_channel')

            # Numerical
            data['no_of_trainings'] = float(request.POST.get('no_of_trainings'))
            data['age'] = float(request.POST.get('age'))
            data['previous_year_rating'] = float(request.POST.get('previous_year_rating'))
            data['length_of_service'] = float(request.POST.get('length_of_service'))
            data['awards_won'] = float(request.POST.get('awards_won'))
            data['avg_training_score'] = float(request.POST.get('avg_training_score'))

            # Encode categorical
            for col in encoders:
                data[col] = encoders[col].transform([data[col]])[0]

            # Convert to array
            final_data = np.array(list(data.values())).reshape(1, -1)

            # Scale
            final_data = scaler.transform(final_data)

            # Prediction
            prediction = model.predict(final_data)[0]

            # Probability
            prob = model.predict_proba(final_data)[0][1]

            confidence = round(prob * 100, 2)
            remaining = round(100 - confidence, 2)

            result = "Promoted ✅" if prediction == 1 else "Not Promoted ❌"

            return render(request, 'index.html', {
                'result': result,
                'confidence': confidence,
                'remaining': remaining,
            })

        except Exception as e:
            return render(request, 'index.html', {
                'error': str(e)
            })

    return render(request, 'index.html')